package br.com.fiap.dao;

import br.com.fiap.conexoes.ConexaoFactory;
import br.com.fiap.entities.Dentista;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class DentistaDAO {

    public Connection minhaConexao;

    public DentistaDAO() throws SQLException, ClassNotFoundException {
        this.minhaConexao = new ConexaoFactory().conexao();
    }

    public String inserir(Dentista d) throws SQLException {
        if (!d.validarCRO()) {
            return "Erro: CRO invalido. Informe exatamente 6 digitos numericos.";
        }
        String sql = "INSERT INTO T_DENTISTA (ID_DENTISTA, NOME, EMAIL, SENHA, CRO, DISPONIBILIDADE) " +
                "VALUES (SEQ_DENTISTA.NEXTVAL, ?, ?, ?, ?, ?)";
        PreparedStatement stmt = minhaConexao.prepareStatement(sql);
        stmt.setString(1, d.getNome());
        stmt.setString(2, d.getEmail());
        stmt.setString(3, d.getSenha());
        stmt.setString(4, d.getCro());
        stmt.setString(5, d.getDisponibilidade());
        stmt.execute();
        stmt.close();
        return "Dentista cadastrado com sucesso!";
    }

    public String atualizar(Dentista d) throws SQLException {
        if (!d.validarCRO()) {
            return "Erro: CRO invalido. Informe exatamente 6 digitos numericos.";
        }
        String sql = "UPDATE T_DENTISTA SET NOME=?, EMAIL=?, SENHA=?, CRO=?, DISPONIBILIDADE=? " +
                "WHERE ID_DENTISTA=?";
        PreparedStatement stmt = minhaConexao.prepareStatement(sql);
        stmt.setString(1, d.getNome());
        stmt.setString(2, d.getEmail());
        stmt.setString(3, d.getSenha());
        stmt.setString(4, d.getCro());
        stmt.setString(5, d.getDisponibilidade());
        stmt.setInt(6, d.getIdDentista());
        stmt.executeUpdate();
        stmt.close();
        return "Dentista atualizado com sucesso!";
    }

    public String deletar(int id) throws SQLException {
        String sql = "DELETE FROM T_DENTISTA WHERE ID_DENTISTA=?";
        PreparedStatement stmt = minhaConexao.prepareStatement(sql);
        stmt.setInt(1, id);
        stmt.execute();
        stmt.close();
        return "Dentista deletado com sucesso!";
    }

    public ArrayList<Dentista> selecionar() throws SQLException {
        ArrayList<Dentista> lista = new ArrayList<>();
        String sql = "SELECT * FROM T_DENTISTA ORDER BY NOME";
        PreparedStatement stmt = minhaConexao.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            Dentista d = new Dentista();
            d.setIdDentista(rs.getInt("ID_DENTISTA"));
            d.setNome(rs.getString("NOME"));
            d.setEmail(rs.getString("EMAIL"));
            d.setSenha(rs.getString("SENHA"));
            d.setCro(rs.getString("CRO"));
            d.setDisponibilidade(rs.getString("DISPONIBILIDADE"));
            lista.add(d);
        }
        return lista;
    }

    public Dentista selecionarPorId(int id) throws SQLException {
        Dentista d = null;
        String sql = "SELECT * FROM T_DENTISTA WHERE ID_DENTISTA=?";
        PreparedStatement stmt = minhaConexao.prepareStatement(sql);
        stmt.setInt(1, id);
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) {
            d = new Dentista();
            d.setIdDentista(rs.getInt("ID_DENTISTA"));
            d.setNome(rs.getString("NOME"));
            d.setEmail(rs.getString("EMAIL"));
            d.setSenha(rs.getString("SENHA"));
            d.setCro(rs.getString("CRO"));
            d.setDisponibilidade(rs.getString("DISPONIBILIDADE"));
        }
        return d;
    }
}
