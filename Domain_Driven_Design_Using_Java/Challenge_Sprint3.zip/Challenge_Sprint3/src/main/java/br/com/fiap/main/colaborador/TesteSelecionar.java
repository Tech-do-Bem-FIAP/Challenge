package br.com.fiap.main.colaborador;

import br.com.fiap.dao.ColaboradorDAO;
import br.com.fiap.entities.Colaborador;

import java.sql.SQLException;
import java.util.ArrayList;

public class TesteSelecionar {

    public static void main(String[] args) throws SQLException, ClassNotFoundException {

        ColaboradorDAO dao = new ColaboradorDAO();

        ArrayList<Colaborador> lista = dao.selecionar();

        if (lista != null) {
            for (Colaborador c : lista) {
                System.out.println(
                        c.getIdColaborador() + " | " +
                        c.getNome() + " | " +
                        c.getEmail() + " | " +
                        c.getCargo() + " | " +
                        c.getDisponibilidade()
                );
            }
        }
    }
}
