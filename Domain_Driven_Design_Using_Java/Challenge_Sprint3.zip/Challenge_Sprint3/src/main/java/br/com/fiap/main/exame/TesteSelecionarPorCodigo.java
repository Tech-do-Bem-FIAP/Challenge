package br.com.fiap.main.exame;

import br.com.fiap.dao.ExameDAO;
import br.com.fiap.entities.Exame;

import javax.swing.*;
import java.sql.SQLException;

public class TesteSelecionarPorCodigo {

    static int inteiro(String j) {
        return Integer.parseInt(JOptionPane.showInputDialog(j));
    }

    public static void main(String[] args) throws SQLException, ClassNotFoundException {

        ExameDAO dao = new ExameDAO();

        int id = inteiro("Informe o ID do exame que gostaria de verificar");

        Exame e = dao.selecionarPorId(id);

        if (e != null) {
            System.out.println(
                    e.getIdExame() + " | " +
                    e.getTipo() + " | " +
                    e.getRequisitos() + " | " +
                    e.getResultado()
            );
        } else {
            System.out.println("Exame não encontrado!");
        }
    }
}
