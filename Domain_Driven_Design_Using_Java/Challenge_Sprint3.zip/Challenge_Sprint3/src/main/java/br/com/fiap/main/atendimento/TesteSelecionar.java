package br.com.fiap.main.atendimento;

import br.com.fiap.dao.AtendimentoDAO;
import br.com.fiap.entities.Atendimento;

import java.sql.SQLException;
import java.util.ArrayList;

public class TesteSelecionar {

    public static void main(String[] args) throws SQLException, ClassNotFoundException {

        AtendimentoDAO dao = new AtendimentoDAO();

        ArrayList<Atendimento> lista = dao.selecionar();

        if (lista != null) {
            for (Atendimento a : lista) {
                System.out.println(
                        a.getIdAtendimento() + " | " +
                        a.getIdPaciente().getNome() + " | " +
                        a.getIdDentista().getNome() + " | " +
                        a.getIdCampanha().getNome() + " | " +
                        a.getData() + " | " +
                        a.getStatus() + " | " +
                        a.getTipo() + " | " +
                        a.getObservacoes()
                );
            }
        }
    }
}
