package br.com.fiap;

import br.com.fiap.conexoes.ConexaoFactory;

import java.sql.Connection;
import java.sql.SQLException;

public class Main {
    public static void main(String[] args) throws SQLException, ClassNotFoundException {

        Connection cn = new ConexaoFactory().conexao();
        System.out.println("Conexão com o banco de dados realizada com sucesso!");
        cn.close();
    }
}
