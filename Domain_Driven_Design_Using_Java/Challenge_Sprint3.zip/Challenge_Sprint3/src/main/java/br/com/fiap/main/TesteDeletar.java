package br.com.fiap.main;

import br.com.fiap.dao.PacienteDAO;

import javax.swing.*;
import java.sql.SQLException;

public class TesteDeletar {

    static int inteiro(String j) {
        return Integer.parseInt(JOptionPane.showInputDialog(j));
    }

    public static void main(String[] args) throws SQLException, ClassNotFoundException {

        PacienteDAO dao = new PacienteDAO();

        int id = inteiro("Informe o ID do paciente que será deletado");

        System.out.println(dao.deletar(id));
    }
}
