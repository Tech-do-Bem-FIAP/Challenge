package br.com.fiap.main.campanha;

import br.com.fiap.dao.CampanhaDAO;

import javax.swing.*;
import java.sql.SQLException;

public class TesteDeletar {

    static int inteiro(String j) {
        return Integer.parseInt(JOptionPane.showInputDialog(j));
    }

    public static void main(String[] args) throws SQLException, ClassNotFoundException {

        CampanhaDAO dao = new CampanhaDAO();

        int id = inteiro("Informe o ID da campanha que será deletada");

        System.out.println(dao.deletar(id));
    }
}
