package br.com.fiap.main.atendimento;

import br.com.fiap.dao.AtendimentoDAO;
import br.com.fiap.entities.Atendimento;

import javax.swing.*;
import java.sql.SQLException;

public class TesteSelecionarPorCodigo {

    static int inteiro(String j) {
        return Integer.parseInt(JOptionPane.showInputDialog(j));
    }

    public static void main(String[] args) throws SQLException, ClassNotFoundException {

        AtendimentoDAO dao = new AtendimentoDAO();

        int id = inteiro("Informe o ID do atendimento que gostaria de verificar");

        Atendimento a = dao.selecionarPorId(id);

        if (a != null) {
            System.out.println(
                    a.getIdAtendimento() + " | " +
                    a.getIdPaciente().getNome() + " | " +
                    a.getIdDentista().getNome() + " | " +
                    a.getIdCampanha().getNome() + " | " +
                    a.getData() + " | " +
                    a.getStatus() + " | " +
                    a.getTipo() + " | " +
                    a.getObservacoes()
            );
        } else {
            System.out.println("Atendimento não encontrado!");
        }
    }
}
