package br.com.fiap.entities;

public class Dentista {

    private int    idDentista;
    private String nome;
    private String email;
    private String senha;
    private String cro;
    private String disponibilidade;

    public Dentista() {
    }

    public Dentista(int idDentista, String nome, String email,
                    String senha, String cro, String disponibilidade) {
        this.idDentista      = idDentista;
        this.nome            = nome;
        this.email           = email;
        this.senha           = senha;
        this.cro             = cro;
        this.disponibilidade = disponibilidade;
    }

    // -------------------------------------------------------------------------
    // Logica de Negocio
    // -------------------------------------------------------------------------


      //Valida se o CRO contem exatamente 6 digitos numericos

    public boolean validarCRO() {
        return this.cro != null && this.cro.matches("\\d{6}");
    }

     // Verifica se o dentista esta disponivel para novos atendimentos.

    public boolean isDisponivel() {
        return "sim".equalsIgnoreCase(this.disponibilidade);
    }

    // -------------------------------------------------------------------------
    // Getters e Setters
    // -------------------------------------------------------------------------

    public int getIdDentista() {
        return idDentista;
    }

    public void setIdDentista(int idDentista) {
        this.idDentista = idDentista;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getCro() {
        return cro;
    }

    public void setCro(String cro) {
        this.cro = cro;
    }

    public String getDisponibilidade() {
        return disponibilidade;
    }

    public void setDisponibilidade(String disponibilidade) {
        this.disponibilidade = disponibilidade;
    }
}
