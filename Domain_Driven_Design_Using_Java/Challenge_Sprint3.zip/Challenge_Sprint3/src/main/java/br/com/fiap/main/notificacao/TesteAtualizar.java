package br.com.fiap.main.notificacao;

import br.com.fiap.dao.NotificacaoDAO;
import br.com.fiap.entities.Notificacao;

import javax.swing.*;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class TesteAtualizar {

    static String texto(String j) {
        return JOptionPane.showInputDialog(j);
    }

    static int inteiro(String j) {
        return Integer.parseInt(JOptionPane.showInputDialog(j));
    }

    public static void main(String[] args) throws SQLException, ClassNotFoundException {

        Notificacao notificacao = new Notificacao();
        NotificacaoDAO dao = new NotificacaoDAO();

        notificacao.setIdNotificacao(inteiro("ID da Notificação que será atualizada"));
        notificacao.setMensagem(texto("Nova Mensagem"));

        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            Date dataEnvio = sdf.parse(texto("Nova Data de Envio (dd/MM/yyyy)"));
            notificacao.setDataEnvio(dataEnvio);
        } catch (ParseException e) {
            System.out.println("Formato de data inválido!");
            return;
        }

        notificacao.setStatusEnvio(texto("Novo Status de Envio (ex: enviado, pendente, falhou)"));
        notificacao.setCanal(texto("Novo Canal (ex: email, sms, push)"));

        System.out.println(dao.atualizar(notificacao));
    }
}
