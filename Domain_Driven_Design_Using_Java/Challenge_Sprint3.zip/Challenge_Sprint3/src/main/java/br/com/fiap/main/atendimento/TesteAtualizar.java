package br.com.fiap.main.atendimento;

import br.com.fiap.dao.AtendimentoDAO;
import br.com.fiap.entities.Atendimento;
import br.com.fiap.entities.Campanha;
import br.com.fiap.entities.Dentista;
import br.com.fiap.entities.Paciente;

import javax.swing.*;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class TesteAtualizar {

    static String texto(String j) {
        return JOptionPane.showInputDialog(j);
    }

    static int inteiro(String j) {
        return Integer.parseInt(JOptionPane.showInputDialog(j));
    }

    public static void main(String[] args) throws SQLException, ClassNotFoundException {

        Atendimento atendimento = new Atendimento();
        AtendimentoDAO dao = new AtendimentoDAO();

        atendimento.setIdAtendimento(inteiro("ID do Atendimento que será atualizado"));

        Paciente paciente = new Paciente();
        paciente.setIdPaciente(inteiro("Novo ID do Paciente"));
        atendimento.setIdPaciente(paciente);

        Dentista dentista = new Dentista();
        dentista.setIdDentista(inteiro("Novo ID do Dentista"));
        atendimento.setIdDentista(dentista);

        Campanha campanha = new Campanha();
        campanha.setIdCampanha(inteiro("Novo ID da Campanha"));
        atendimento.setIdCampanha(campanha);

        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            Date data = sdf.parse(texto("Nova Data do Atendimento (dd/MM/yyyy)"));
            atendimento.setData(data);
        } catch (ParseException e) {
            System.out.println("Formato de data inválido!");
            return;
        }

        atendimento.setStatus(texto("Novo Status (ex: agendado, concluido, cancelado)"));
        atendimento.setTipo(texto("Novo Tipo"));
        atendimento.setObservacoes(texto("Novas Observações"));

        System.out.println(dao.atualizar(atendimento));
    }
}
