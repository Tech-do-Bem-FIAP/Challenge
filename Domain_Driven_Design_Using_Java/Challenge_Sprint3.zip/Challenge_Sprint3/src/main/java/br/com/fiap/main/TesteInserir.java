package br.com.fiap.main;

import br.com.fiap.dao.PacienteDAO;
import br.com.fiap.entities.Paciente;

import javax.swing.*;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class TesteInserir {

    static String texto(String j) {
        return JOptionPane.showInputDialog(j);
    }

    static int inteiro(String j) {
        return Integer.parseInt(JOptionPane.showInputDialog(j));
    }

    public static void main(String[] args) throws SQLException, ClassNotFoundException {

        Paciente paciente = new Paciente();
        PacienteDAO dao = new PacienteDAO();

        paciente.setIdPaciente(inteiro("ID do Paciente"));
        paciente.setNome(texto("Nome"));
        paciente.setEmail(texto("Email"));
        paciente.setTelefone(texto("Telefone"));

        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            Date dataNasc = sdf.parse(texto("Data de Nascimento (dd/MM/yyyy)"));
            paciente.setDataNasc(dataNasc);
        } catch (ParseException e) {
            System.out.println("Formato de data inválido!");
            return;
        }

        System.out.println(dao.inserir(paciente));
    }
}