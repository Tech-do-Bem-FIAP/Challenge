package br.com.fiap.dao;

import br.com.fiap.conexoes.ConexaoFactory;
import br.com.fiap.entities.Paciente;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class PacienteDAO {

    public Connection minhaConexao;

    public PacienteDAO() throws SQLException, ClassNotFoundException {
        this.minhaConexao = new ConexaoFactory().conexao();
    }

    public String inserir(Paciente p) throws SQLException {
        String sql = "INSERT INTO T_PACIENTE (ID_PACIENTE, NOME, DATA_NASC, TELEFONE, EMAIL) " +
                "VALUES (SEQ_PACIENTE.NEXTVAL, ?, ?, ?, ?)";
        PreparedStatement stmt = minhaConexao.prepareStatement(sql);
        stmt.setString(1, p.getNome());
        stmt.setDate(2, new java.sql.Date(p.getDataNasc().getTime()));
        stmt.setString(3, p.getTelefone());
        stmt.setString(4, p.getEmail());
        stmt.execute();
        stmt.close();
        return "Paciente cadastrado com sucesso!";
    }

    public String atualizar(Paciente p) throws SQLException {
        String sql = "UPDATE T_PACIENTE SET NOME=?, DATA_NASC=?, TELEFONE=?, EMAIL=? " +
                "WHERE ID_PACIENTE=?";
        PreparedStatement stmt = minhaConexao.prepareStatement(sql);
        stmt.setString(1, p.getNome());
        stmt.setDate(2, new java.sql.Date(p.getDataNasc().getTime()));
        stmt.setString(3, p.getTelefone());
        stmt.setString(4, p.getEmail());
        stmt.setInt(5, p.getIdPaciente());
        stmt.executeUpdate();
        stmt.close();
        return "Paciente atualizado com sucesso!";
    }

    public String deletar(int id) throws SQLException {
        String sql = "DELETE FROM T_PACIENTE WHERE ID_PACIENTE=?";
        PreparedStatement stmt = minhaConexao.prepareStatement(sql);
        stmt.setInt(1, id);
        stmt.execute();
        stmt.close();
        return "Paciente deletado com sucesso!";
    }

    public ArrayList<Paciente> selecionar() throws SQLException {
        ArrayList<Paciente> lista = new ArrayList<>();
        String sql = "SELECT * FROM T_PACIENTE ORDER BY NOME";
        PreparedStatement stmt = minhaConexao.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            Paciente p = new Paciente();
            p.setIdPaciente(rs.getInt("ID_PACIENTE"));
            p.setNome(rs.getString("NOME"));
            p.setDataNasc(rs.getDate("DATA_NASC"));
            p.setTelefone(rs.getString("TELEFONE"));
            p.setEmail(rs.getString("EMAIL"));
            lista.add(p);
        }
        return lista;
    }

    public Paciente selecionarPorId(int id) throws SQLException {
        Paciente p = null;
        String sql = "SELECT * FROM T_PACIENTE WHERE ID_PACIENTE=?";
        PreparedStatement stmt = minhaConexao.prepareStatement(sql);
        stmt.setInt(1, id);
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) {
            p = new Paciente();
            p.setIdPaciente(rs.getInt("ID_PACIENTE"));
            p.setNome(rs.getString("NOME"));
            p.setDataNasc(rs.getDate("DATA_NASC"));
            p.setTelefone(rs.getString("TELEFONE"));
            p.setEmail(rs.getString("EMAIL"));
        }
        return p;
    }
}
