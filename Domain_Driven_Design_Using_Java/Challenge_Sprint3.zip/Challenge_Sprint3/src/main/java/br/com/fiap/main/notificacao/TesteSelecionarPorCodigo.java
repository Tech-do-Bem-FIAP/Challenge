package br.com.fiap.main.notificacao;

import br.com.fiap.dao.NotificacaoDAO;
import br.com.fiap.entities.Notificacao;

import javax.swing.*;
import java.sql.SQLException;

public class TesteSelecionarPorCodigo {

    static int inteiro(String j) {
        return Integer.parseInt(JOptionPane.showInputDialog(j));
    }

    public static void main(String[] args) throws SQLException, ClassNotFoundException {

        NotificacaoDAO dao = new NotificacaoDAO();

        int id = inteiro("Informe o ID da notificação que gostaria de verificar");

        Notificacao n = dao.selecionarPorId(id);

        if (n != null) {
            System.out.println(
                    n.getIdNotificacao() + " | " +
                    n.getMensagem() + " | " +
                    n.getDataEnvio() + " | " +
                    n.getStatusEnvio() + " | " +
                    n.getCanal()
            );
        } else {
            System.out.println("Notificação não encontrada!");
        }
    }
}
