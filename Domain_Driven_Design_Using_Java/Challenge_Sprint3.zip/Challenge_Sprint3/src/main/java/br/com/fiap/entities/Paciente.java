package br.com.fiap.entities;

import java.util.Calendar;
import java.util.Date;

public class Paciente {

    private int    idPaciente;
    private String nome;
    private Date   dataNasc;
    private String telefone;
    private String email;

    public Paciente() {
    }

    public Paciente(int idPaciente, String nome, Date dataNasc,
                    String telefone, String email) {
        this.idPaciente = idPaciente;
        this.nome       = nome;
        this.dataNasc   = dataNasc;
        this.telefone   = telefone;
        this.email      = email;
    }

    // -------------------------------------------------------------------------
    // Logica de Negocio
    // -------------------------------------------------------------------------

    //Calcula a idade real do paciente em anos completos.

    public int calcularIdade() {
        if (this.dataNasc == null) return 0;
        Calendar nascimento = Calendar.getInstance();
        nascimento.setTime(this.dataNasc);
        Calendar hoje = Calendar.getInstance();
        int idade = hoje.get(Calendar.YEAR) - nascimento.get(Calendar.YEAR);
        if (hoje.get(Calendar.DAY_OF_YEAR) < nascimento.get(Calendar.DAY_OF_YEAR)) {
            idade--;
        }
        return idade;
    }

     // Quando verdadeiro, o atendimento exige autorizacao de responsavel.

    public boolean isMenorDeIdade() {
        return calcularIdade() < 18;
    }


    public int getIdPaciente() {
        return idPaciente;
    }

    public void setIdPaciente(int idPaciente) {
        this.idPaciente = idPaciente;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Date getDataNasc() {
        return dataNasc;
    }

    public void setDataNasc(Date dataNasc) {
        this.dataNasc = dataNasc;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
