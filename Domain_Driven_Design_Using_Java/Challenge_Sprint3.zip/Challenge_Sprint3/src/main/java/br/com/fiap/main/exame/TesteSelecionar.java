package br.com.fiap.main.exame;

import br.com.fiap.dao.ExameDAO;
import br.com.fiap.entities.Exame;

import java.sql.SQLException;
import java.util.ArrayList;

public class TesteSelecionar {

    public static void main(String[] args) throws SQLException, ClassNotFoundException {

        ExameDAO dao = new ExameDAO();

        ArrayList<Exame> lista = dao.selecionar();

        if (lista != null) {
            for (Exame e : lista) {
                System.out.println(
                        e.getIdExame() + " | " +
                        e.getTipo() + " | " +
                        e.getRequisitos() + " | " +
                        e.getResultado()
                );
            }
        }
    }
}
