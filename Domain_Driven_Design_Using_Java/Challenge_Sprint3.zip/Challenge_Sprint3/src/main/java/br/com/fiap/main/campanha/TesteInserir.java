package br.com.fiap.main.campanha;

import br.com.fiap.dao.CampanhaDAO;
import br.com.fiap.entities.Campanha;

import javax.swing.*;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class TesteInserir {

    static String texto(String j) {
        return JOptionPane.showInputDialog(j);
    }

    public static void main(String[] args) throws SQLException, ClassNotFoundException {

        Campanha campanha = new Campanha();
        CampanhaDAO dao = new CampanhaDAO();

        campanha.setNome(texto("Nome da Campanha"));
        campanha.setLocal(texto("Local"));

        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            Date dataInicio = sdf.parse(texto("Data de Início (dd/MM/yyyy)"));
            campanha.setDataInicio(dataInicio);
            Date dataFim = sdf.parse(texto("Data de Fim (dd/MM/yyyy)"));
            campanha.setDataFim(dataFim);
        } catch (ParseException e) {
            System.out.println("Formato de data inválido!");
            return;
        }

        System.out.println(dao.inserir(campanha));
    }
}
