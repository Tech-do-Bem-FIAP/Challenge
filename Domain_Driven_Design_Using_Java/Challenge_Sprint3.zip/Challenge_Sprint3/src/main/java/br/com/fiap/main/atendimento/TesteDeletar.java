package br.com.fiap.main.atendimento;

import br.com.fiap.dao.AtendimentoDAO;

import javax.swing.*;
import java.sql.SQLException;

public class TesteDeletar {

    static int inteiro(String j) {
        return Integer.parseInt(JOptionPane.showInputDialog(j));
    }

    public static void main(String[] args) throws SQLException, ClassNotFoundException {

        AtendimentoDAO dao = new AtendimentoDAO();

        int id = inteiro("Informe o ID do atendimento que será deletado");

        System.out.println(dao.deletar(id));
    }
}
