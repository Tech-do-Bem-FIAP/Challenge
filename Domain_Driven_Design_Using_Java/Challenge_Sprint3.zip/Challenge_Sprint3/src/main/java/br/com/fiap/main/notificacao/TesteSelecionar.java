package br.com.fiap.main.notificacao;

import br.com.fiap.dao.NotificacaoDAO;
import br.com.fiap.entities.Notificacao;

import java.sql.SQLException;
import java.util.ArrayList;

public class TesteSelecionar {

    public static void main(String[] args) throws SQLException, ClassNotFoundException {

        NotificacaoDAO dao = new NotificacaoDAO();

        ArrayList<Notificacao> lista = dao.selecionar();

        if (lista != null) {
            for (Notificacao n : lista) {
                System.out.println(
                        n.getIdNotificacao() + " | " +
                        n.getMensagem() + " | " +
                        n.getDataEnvio() + " | " +
                        n.getStatusEnvio() + " | " +
                        n.getCanal()
                );
            }
        }
    }
}
