package br.com.fiap.main.dentista;

import br.com.fiap.dao.DentistaDAO;
import br.com.fiap.entities.Dentista;

import javax.swing.*;
import java.sql.SQLException;

public class TesteInserir {

    static String texto(String j) {
        return JOptionPane.showInputDialog(j);
    }

    public static void main(String[] args) throws SQLException, ClassNotFoundException {

        Dentista dentista = new Dentista();
        DentistaDAO dao = new DentistaDAO();

        dentista.setNome(texto("Nome"));
        dentista.setEmail(texto("Email"));
        dentista.setSenha(texto("Senha"));
        dentista.setCro(texto("CRO (6 dígitos numéricos)"));
        dentista.setDisponibilidade(texto("Disponibilidade (sim/nao)"));

        System.out.println(dao.inserir(dentista));
    }
}
