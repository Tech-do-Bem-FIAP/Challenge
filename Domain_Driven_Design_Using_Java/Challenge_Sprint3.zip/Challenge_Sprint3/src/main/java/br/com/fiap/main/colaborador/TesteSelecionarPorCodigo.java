package br.com.fiap.main.colaborador;

import br.com.fiap.dao.ColaboradorDAO;
import br.com.fiap.entities.Colaborador;

import javax.swing.*;
import java.sql.SQLException;

public class TesteSelecionarPorCodigo {

    static int inteiro(String j) {
        return Integer.parseInt(JOptionPane.showInputDialog(j));
    }

    public static void main(String[] args) throws SQLException, ClassNotFoundException {

        ColaboradorDAO dao = new ColaboradorDAO();

        int id = inteiro("Informe o ID do colaborador que gostaria de verificar");

        Colaborador c = dao.selecionarPorId(id);

        if (c != null) {
            System.out.println(
                    c.getIdColaborador() + " | " +
                    c.getNome() + " | " +
                    c.getEmail() + " | " +
                    c.getCargo() + " | " +
                    c.getDisponibilidade()
            );
        } else {
            System.out.println("Colaborador não encontrado!");
        }
    }
}
