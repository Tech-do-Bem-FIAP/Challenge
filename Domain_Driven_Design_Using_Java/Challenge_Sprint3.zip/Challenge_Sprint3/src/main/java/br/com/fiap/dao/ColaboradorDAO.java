package br.com.fiap.dao;

import br.com.fiap.conexoes.ConexaoFactory;
import br.com.fiap.entities.Colaborador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class ColaboradorDAO {

    public Connection minhaConexao;

    public ColaboradorDAO() throws SQLException, ClassNotFoundException {
        this.minhaConexao = new ConexaoFactory().conexao();
    }

    public String inserir(Colaborador c) throws SQLException {
        String sql = "INSERT INTO T_COLABORADOR (ID_COLABORADOR, NOME, EMAIL, SENHA, CARGO, DISPONIBILIDADE) " +
                "VALUES (SEQ_COLABORADOR.NEXTVAL, ?, ?, ?, ?, ?)";
        PreparedStatement stmt = minhaConexao.prepareStatement(sql);
        stmt.setString(1, c.getNome());
        stmt.setString(2, c.getEmail());
        stmt.setString(3, c.getSenha());
        stmt.setString(4, c.getCargo());
        stmt.setString(5, c.getDisponibilidade());
        stmt.execute();
        stmt.close();
        return "Colaborador cadastrado com sucesso!";
    }

    public String atualizar(Colaborador c) throws SQLException {
        String sql = "UPDATE T_COLABORADOR SET NOME=?, EMAIL=?, SENHA=?, CARGO=?, DISPONIBILIDADE=? " +
                "WHERE ID_COLABORADOR=?";
        PreparedStatement stmt = minhaConexao.prepareStatement(sql);
        stmt.setString(1, c.getNome());
        stmt.setString(2, c.getEmail());
        stmt.setString(3, c.getSenha());
        stmt.setString(4, c.getCargo());
        stmt.setString(5, c.getDisponibilidade());
        stmt.setInt(6, c.getIdColaborador());
        stmt.executeUpdate();
        stmt.close();
        return "Colaborador atualizado com sucesso!";
    }

    public String deletar(int id) throws SQLException {
        String sql = "DELETE FROM T_COLABORADOR WHERE ID_COLABORADOR=?";
        PreparedStatement stmt = minhaConexao.prepareStatement(sql);
        stmt.setInt(1, id);
        stmt.execute();
        stmt.close();
        return "Colaborador deletado com sucesso!";
    }

    public ArrayList<Colaborador> selecionar() throws SQLException {
        ArrayList<Colaborador> lista = new ArrayList<>();
        String sql = "SELECT * FROM T_COLABORADOR ORDER BY NOME";
        PreparedStatement stmt = minhaConexao.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            Colaborador c = new Colaborador();
            c.setIdColaborador(rs.getInt("ID_COLABORADOR"));
            c.setNome(rs.getString("NOME"));
            c.setEmail(rs.getString("EMAIL"));
            c.setSenha(rs.getString("SENHA"));
            c.setCargo(rs.getString("CARGO"));
            c.setDisponibilidade(rs.getString("DISPONIBILIDADE"));
            lista.add(c);
        }
        return lista;
    }

    public Colaborador selecionarPorId(int id) throws SQLException {
        Colaborador c = null;
        String sql = "SELECT * FROM T_COLABORADOR WHERE ID_COLABORADOR=?";
        PreparedStatement stmt = minhaConexao.prepareStatement(sql);
        stmt.setInt(1, id);
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) {
            c = new Colaborador();
            c.setIdColaborador(rs.getInt("ID_COLABORADOR"));
            c.setNome(rs.getString("NOME"));
            c.setEmail(rs.getString("EMAIL"));
            c.setSenha(rs.getString("SENHA"));
            c.setCargo(rs.getString("CARGO"));
            c.setDisponibilidade(rs.getString("DISPONIBILIDADE"));
        }
        return c;
    }
}
