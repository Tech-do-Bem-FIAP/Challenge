package br.com.fiap.main;

import br.com.fiap.dao.PacienteDAO;
import br.com.fiap.entities.Paciente;

import java.sql.SQLException;
import java.util.ArrayList;

public class TesteSelecionar {

    public static void main(String[] args) throws SQLException, ClassNotFoundException {

        PacienteDAO dao = new PacienteDAO();

        ArrayList<Paciente> lista = dao.selecionar();

        if (lista != null) {
            for (Paciente p : lista) {
                System.out.println(
                        p.getIdPaciente() + " | " +
                                p.getNome() + " | " +
                                p.getEmail() + " | " +
                                p.getTelefone() + " | " +
                                p.getDataNasc() + " | " +
                                p.calcularIdade()
                );
            }
        }
    }
}