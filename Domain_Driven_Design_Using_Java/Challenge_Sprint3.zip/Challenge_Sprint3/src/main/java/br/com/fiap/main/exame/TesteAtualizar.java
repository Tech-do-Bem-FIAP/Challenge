package br.com.fiap.main.exame;

import br.com.fiap.dao.ExameDAO;
import br.com.fiap.entities.Exame;

import javax.swing.*;
import java.sql.SQLException;

public class TesteAtualizar {

    static String texto(String j) {
        return JOptionPane.showInputDialog(j);
    }

    static int inteiro(String j) {
        return Integer.parseInt(JOptionPane.showInputDialog(j));
    }

    public static void main(String[] args) throws SQLException, ClassNotFoundException {

        Exame exame = new Exame();
        ExameDAO dao = new ExameDAO();

        exame.setIdExame(inteiro("ID do Exame que será atualizado"));
        exame.setTipo(texto("Novo Tipo"));
        exame.setRequisitos(texto("Novos Requisitos"));
        exame.setResultado(texto("Novo Resultado"));

        System.out.println(dao.atualizar(exame));
    }
}
