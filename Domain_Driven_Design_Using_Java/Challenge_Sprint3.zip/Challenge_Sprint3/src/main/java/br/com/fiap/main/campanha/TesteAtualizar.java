package br.com.fiap.main.campanha;

import br.com.fiap.dao.CampanhaDAO;
import br.com.fiap.entities.Campanha;

import javax.swing.*;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class TesteAtualizar {

    static String texto(String j) {
        return JOptionPane.showInputDialog(j);
    }

    static int inteiro(String j) {
        return Integer.parseInt(JOptionPane.showInputDialog(j));
    }

    public static void main(String[] args) throws SQLException, ClassNotFoundException {

        Campanha campanha = new Campanha();
        CampanhaDAO dao = new CampanhaDAO();

        campanha.setIdCampanha(inteiro("ID da Campanha que será atualizada"));
        campanha.setNome(texto("Novo Nome"));
        campanha.setLocal(texto("Novo Local"));

        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            Date dataInicio = sdf.parse(texto("Nova Data de Início (dd/MM/yyyy)"));
            campanha.setDataInicio(dataInicio);
            Date dataFim = sdf.parse(texto("Nova Data de Fim (dd/MM/yyyy)"));
            campanha.setDataFim(dataFim);
        } catch (ParseException e) {
            System.out.println("Formato de data inválido!");
            return;
        }

        System.out.println(dao.atualizar(campanha));
    }
}
