package br.com.fiap.entities;

import java.util.Date;

public class Notificacao {

    private int idNotificacao;
    private String mensagem;
    private Date dataEnvio;
    private String statusEnvio;
    private String canal;

    public Notificacao() {
    }

    public Notificacao(int idNotificacao, String mensagem, Date dataEnvio, String statusEnvio, String canal) {

        this.idNotificacao = idNotificacao;
        this.mensagem = mensagem;
        this.dataEnvio = dataEnvio;
        this.statusEnvio = statusEnvio;
        this.canal = canal;
    }

    public int getIdNotificacao() {
        return idNotificacao;
    }

    public void setIdNotificacao(int idNotificacao) {
        this.idNotificacao = idNotificacao;
    }

    public String getMensagem() {
        return mensagem;
    }

    public void setMensagem(String mensagem) {
        this.mensagem = mensagem;
    }

    public Date getDataEnvio() {
        return dataEnvio;
    }

    public void setDataEnvio(Date dataEnvio) {
        this.dataEnvio = dataEnvio;
    }

    public String getStatusEnvio() {
        return statusEnvio;
    }

    public void setStatusEnvio(String statusEnvio) {
        this.statusEnvio = statusEnvio;
    }

    public String getCanal() {
        return canal;
    }

    public void setCanal(String canal) {
        this.canal = canal;
    }
}