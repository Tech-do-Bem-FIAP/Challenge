package br.com.fiap.main.dentista;

import br.com.fiap.dao.DentistaDAO;

import javax.swing.*;
import java.sql.SQLException;

public class TesteDeletar {

    static int inteiro(String j) {
        return Integer.parseInt(JOptionPane.showInputDialog(j));
    }

    public static void main(String[] args) throws SQLException, ClassNotFoundException {

        DentistaDAO dao = new DentistaDAO();

        int id = inteiro("Informe o ID do dentista que será deletado");

        System.out.println(dao.deletar(id));
    }
}
