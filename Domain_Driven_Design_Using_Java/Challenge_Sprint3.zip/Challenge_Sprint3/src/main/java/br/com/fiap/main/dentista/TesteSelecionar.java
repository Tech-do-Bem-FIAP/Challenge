package br.com.fiap.main.dentista;

import br.com.fiap.dao.DentistaDAO;
import br.com.fiap.entities.Dentista;

import java.sql.SQLException;
import java.util.ArrayList;

public class TesteSelecionar {

    public static void main(String[] args) throws SQLException, ClassNotFoundException {

        DentistaDAO dao = new DentistaDAO();

        ArrayList<Dentista> lista = dao.selecionar();

        if (lista != null) {
            for (Dentista d : lista) {
                System.out.println(
                        d.getIdDentista() + " | " +
                        d.getNome() + " | " +
                        d.getEmail() + " | " +
                        d.getCro() + " | " +
                        d.getDisponibilidade()
                );
            }
        }
    }
}
