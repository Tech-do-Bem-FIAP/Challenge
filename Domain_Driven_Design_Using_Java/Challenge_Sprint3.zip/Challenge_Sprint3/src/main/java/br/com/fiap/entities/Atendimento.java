package br.com.fiap.entities;

import java.util.Date;

public class Atendimento {

    private int      idAtendimento;
    private Paciente idPaciente;
    private Dentista idDentista;
    private Campanha idCampanha;
    private Date     data;
    private String   status;
    private String   tipo;
    private String   observacoes;

    public Atendimento() {
    }

    public Atendimento(int idAtendimento, Paciente idPaciente, Dentista idDentista,
                       Campanha idCampanha, Date data, String status,
                       String tipo, String observacoes) {
        this.idAtendimento = idAtendimento;
        this.idPaciente    = idPaciente;
        this.idDentista    = idDentista;
        this.idCampanha    = idCampanha;
        this.data          = data;
        this.status        = status;
        this.tipo          = tipo;
        this.observacoes   = observacoes;
    }


    // Logica de Negocio:


     //Identifica atendimentos agendados para o futuro.

    public boolean isFuturo() {
        return this.data != null && this.data.after(new Date());
    }


     //Marca atendimentos ja finalizados.

    public boolean isConcluido() {
        return "concluido".equalsIgnoreCase(this.status);
    }


      //Verifica se ha dentista responsavel vinculado ao atendimento.

    public boolean temDentista() {
        return this.idDentista != null;
    }


    public int getIdAtendimento() {
        return idAtendimento;
    }

    public void setIdAtendimento(int idAtendimento) {
        this.idAtendimento = idAtendimento;
    }

    public Paciente getIdPaciente() {
        return idPaciente;
    }

    public void setIdPaciente(Paciente idPaciente) {
        this.idPaciente = idPaciente;
    }

    public Dentista getIdDentista() {
        return idDentista;
    }

    public void setIdDentista(Dentista idDentista) {
        this.idDentista = idDentista;
    }

    public Campanha getIdCampanha() {
        return idCampanha;
    }

    public void setIdCampanha(Campanha idCampanha) {
        this.idCampanha = idCampanha;
    }

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getObservacoes() {
        return observacoes;
    }

    public void setObservacoes(String observacoes) {
        this.observacoes = observacoes;
    }
}
