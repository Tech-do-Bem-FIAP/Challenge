package br.com.fiap.main.exame;

import br.com.fiap.dao.ExameDAO;

import javax.swing.*;
import java.sql.SQLException;

public class TesteDeletar {

    static int inteiro(String j) {
        return Integer.parseInt(JOptionPane.showInputDialog(j));
    }

    public static void main(String[] args) throws SQLException, ClassNotFoundException {

        ExameDAO dao = new ExameDAO();

        int id = inteiro("Informe o ID do exame que será deletado");

        System.out.println(dao.deletar(id));
    }
}
