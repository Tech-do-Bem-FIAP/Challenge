package br.com.fiap.dao;

import br.com.fiap.conexoes.ConexaoFactory;
import br.com.fiap.entities.Notificacao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class NotificacaoDAO {

    public Connection minhaConexao;

    public NotificacaoDAO() throws SQLException, ClassNotFoundException {
        this.minhaConexao = new ConexaoFactory().conexao();
    }

    public String inserir(Notificacao n) throws SQLException {
        String sql = "INSERT INTO T_NOTIFICACAO (ID_NOTIFICACAO, MENSAGEM, DATA_ENVIO, STATUS_ENVIO, CANAL) " +
                "VALUES (SEQ_NOTIFICACAO.NEXTVAL, ?, ?, ?, ?)";
        PreparedStatement stmt = minhaConexao.prepareStatement(sql);
        stmt.setString(1, n.getMensagem());
        stmt.setDate(2, new java.sql.Date(n.getDataEnvio().getTime()));
        stmt.setString(3, n.getStatusEnvio());
        stmt.setString(4, n.getCanal());
        stmt.execute();
        stmt.close();
        return "Notificacao cadastrada com sucesso!";
    }

    public String atualizar(Notificacao n) throws SQLException {
        String sql = "UPDATE T_NOTIFICACAO SET MENSAGEM=?, DATA_ENVIO=?, STATUS_ENVIO=?, CANAL=? " +
                "WHERE ID_NOTIFICACAO=?";
        PreparedStatement stmt = minhaConexao.prepareStatement(sql);
        stmt.setString(1, n.getMensagem());
        stmt.setDate(2, new java.sql.Date(n.getDataEnvio().getTime()));
        stmt.setString(3, n.getStatusEnvio());
        stmt.setString(4, n.getCanal());
        stmt.setInt(5, n.getIdNotificacao());
        stmt.executeUpdate();
        stmt.close();
        return "Notificacao atualizada com sucesso!";
    }

    public String deletar(int id) throws SQLException {
        String sql = "DELETE FROM T_NOTIFICACAO WHERE ID_NOTIFICACAO=?";
        PreparedStatement stmt = minhaConexao.prepareStatement(sql);
        stmt.setInt(1, id);
        stmt.execute();
        stmt.close();
        return "Notificacao deletada com sucesso!";
    }

    public ArrayList<Notificacao> selecionar() throws SQLException {
        ArrayList<Notificacao> lista = new ArrayList<>();
        String sql = "SELECT * FROM T_NOTIFICACAO ORDER BY DATA_ENVIO DESC";
        PreparedStatement stmt = minhaConexao.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            Notificacao n = new Notificacao();
            n.setIdNotificacao(rs.getInt("ID_NOTIFICACAO"));
            n.setMensagem(rs.getString("MENSAGEM"));
            n.setDataEnvio(rs.getDate("DATA_ENVIO"));
            n.setStatusEnvio(rs.getString("STATUS_ENVIO"));
            n.setCanal(rs.getString("CANAL"));
            lista.add(n);
        }
        return lista;
    }

    public Notificacao selecionarPorId(int id) throws SQLException {
        Notificacao n = null;
        String sql = "SELECT * FROM T_NOTIFICACAO WHERE ID_NOTIFICACAO=?";
        PreparedStatement stmt = minhaConexao.prepareStatement(sql);
        stmt.setInt(1, id);
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) {
            n = new Notificacao();
            n.setIdNotificacao(rs.getInt("ID_NOTIFICACAO"));
            n.setMensagem(rs.getString("MENSAGEM"));
            n.setDataEnvio(rs.getDate("DATA_ENVIO"));
            n.setStatusEnvio(rs.getString("STATUS_ENVIO"));
            n.setCanal(rs.getString("CANAL"));
        }
        return n;
    }
}
