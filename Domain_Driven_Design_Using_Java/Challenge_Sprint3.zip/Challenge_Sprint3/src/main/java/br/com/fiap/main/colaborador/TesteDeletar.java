package br.com.fiap.main.colaborador;

import br.com.fiap.dao.ColaboradorDAO;

import javax.swing.*;
import java.sql.SQLException;

public class TesteDeletar {

    static int inteiro(String j) {
        return Integer.parseInt(JOptionPane.showInputDialog(j));
    }

    public static void main(String[] args) throws SQLException, ClassNotFoundException {

        ColaboradorDAO dao = new ColaboradorDAO();

        int id = inteiro("Informe o ID do colaborador que será deletado");

        System.out.println(dao.deletar(id));
    }
}
