package br.com.fiap.main.colaborador;

import br.com.fiap.dao.ColaboradorDAO;
import br.com.fiap.entities.Colaborador;

import javax.swing.*;
import java.sql.SQLException;

public class TesteInserir {

    static String texto(String j) {
        return JOptionPane.showInputDialog(j);
    }

    public static void main(String[] args) throws SQLException, ClassNotFoundException {

        Colaborador colaborador = new Colaborador();
        ColaboradorDAO dao = new ColaboradorDAO();

        colaborador.setNome(texto("Nome"));
        colaborador.setEmail(texto("Email"));
        colaborador.setSenha(texto("Senha"));
        colaborador.setCargo(texto("Cargo"));
        colaborador.setDisponibilidade(texto("Disponibilidade (sim/nao)"));

        System.out.println(dao.inserir(colaborador));
    }
}
