package br.com.fiap.main.dentista;

import br.com.fiap.dao.DentistaDAO;
import br.com.fiap.entities.Dentista;

import javax.swing.*;
import java.sql.SQLException;

public class TesteAtualizar {

    static String texto(String j) {
        return JOptionPane.showInputDialog(j);
    }

    static int inteiro(String j) {
        return Integer.parseInt(JOptionPane.showInputDialog(j));
    }

    public static void main(String[] args) throws SQLException, ClassNotFoundException {

        Dentista dentista = new Dentista();
        DentistaDAO dao = new DentistaDAO();

        dentista.setIdDentista(inteiro("ID do Dentista que será atualizado"));
        dentista.setNome(texto("Novo Nome"));
        dentista.setEmail(texto("Novo Email"));
        dentista.setSenha(texto("Nova Senha"));
        dentista.setCro(texto("Novo CRO (6 dígitos numéricos)"));
        dentista.setDisponibilidade(texto("Nova Disponibilidade (sim/nao)"));

        System.out.println(dao.atualizar(dentista));
    }
}
