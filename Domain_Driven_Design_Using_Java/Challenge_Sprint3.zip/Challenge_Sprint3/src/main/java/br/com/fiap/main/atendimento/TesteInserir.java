package br.com.fiap.main.atendimento;

import br.com.fiap.dao.AtendimentoDAO;
import br.com.fiap.entities.Atendimento;
import br.com.fiap.entities.Campanha;
import br.com.fiap.entities.Dentista;
import br.com.fiap.entities.Paciente;

import javax.swing.*;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class TesteInserir {

    static String texto(String j) {
        return JOptionPane.showInputDialog(j);
    }

    static int inteiro(String j) {
        return Integer.parseInt(JOptionPane.showInputDialog(j));
    }

    public static void main(String[] args) throws SQLException, ClassNotFoundException {

        Atendimento atendimento = new Atendimento();
        AtendimentoDAO dao = new AtendimentoDAO();

        Paciente paciente = new Paciente();
        paciente.setIdPaciente(inteiro("ID do Paciente"));
        atendimento.setIdPaciente(paciente);

        Dentista dentista = new Dentista();
        dentista.setIdDentista(inteiro("ID do Dentista"));
        atendimento.setIdDentista(dentista);

        Campanha campanha = new Campanha();
        campanha.setIdCampanha(inteiro("ID da Campanha"));
        atendimento.setIdCampanha(campanha);

        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            Date data = sdf.parse(texto("Data do Atendimento (dd/MM/yyyy)"));
            atendimento.setData(data);
        } catch (ParseException e) {
            System.out.println("Formato de data inválido!");
            return;
        }

        atendimento.setStatus(texto("Status (ex: agendado, concluido, cancelado)"));
        atendimento.setTipo(texto("Tipo"));
        atendimento.setObservacoes(texto("Observações"));

        System.out.println(dao.inserir(atendimento));
    }
}
