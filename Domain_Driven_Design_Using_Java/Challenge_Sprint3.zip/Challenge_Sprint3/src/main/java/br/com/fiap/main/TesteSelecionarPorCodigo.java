package br.com.fiap.main;

import br.com.fiap.dao.PacienteDAO;
import br.com.fiap.entities.Paciente;

import javax.swing.*;
import java.sql.SQLException;

public class TesteSelecionarPorCodigo {

    static int inteiro(String j) {
        return Integer.parseInt(JOptionPane.showInputDialog(j));
    }

    public static void main(String[] args) throws SQLException, ClassNotFoundException {

        PacienteDAO dao = new PacienteDAO();

        int id = inteiro("Informe o ID do paciente que gostaria de verificar");

        Paciente p = dao.selecionarPorId(id);

        if (p != null) {
            System.out.println(
                    p.getIdPaciente() + " | " +
                            p.getNome() + " | " +
                            p.getEmail() + " | " +
                            p.getTelefone() + " | " +
                            p.getDataNasc() + " | " +
                            p.calcularIdade()
            );
        } else {
            System.out.println("Paciente não encontrado!");
        }
    }
}