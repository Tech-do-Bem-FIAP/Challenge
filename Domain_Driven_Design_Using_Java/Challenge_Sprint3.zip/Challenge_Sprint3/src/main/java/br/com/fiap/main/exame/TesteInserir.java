package br.com.fiap.main.exame;

import br.com.fiap.dao.ExameDAO;
import br.com.fiap.entities.Exame;

import javax.swing.*;
import java.sql.SQLException;

public class TesteInserir {

    static String texto(String j) {
        return JOptionPane.showInputDialog(j);
    }

    public static void main(String[] args) throws SQLException, ClassNotFoundException {

        Exame exame = new Exame();
        ExameDAO dao = new ExameDAO();

        exame.setTipo(texto("Tipo do Exame"));
        exame.setRequisitos(texto("Requisitos"));
        exame.setResultado(texto("Resultado"));

        System.out.println(dao.inserir(exame));
    }
}
