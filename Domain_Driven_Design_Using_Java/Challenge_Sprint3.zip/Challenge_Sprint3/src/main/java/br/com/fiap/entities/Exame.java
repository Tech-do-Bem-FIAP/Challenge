package br.com.fiap.entities;

public class Exame {

    private int    idExame;
    private String tipo;
    private String requisitos;
    private String resultado;

    public Exame() {
    }

    public Exame(int idExame, String tipo, String requisitos, String resultado) {
        this.idExame    = idExame;
        this.tipo       = tipo;
        this.requisitos = requisitos;
        this.resultado  = resultado;
    }


    // Logica de Negocio:


     //Verifica se o exame ja tem resultado lancado.

    public boolean temResultado() {
        return this.resultado != null && !this.resultado.isBlank();
    }


     //Verifica se o resultado do exame indica normalidade.

    public boolean isResultadoNormal() {
        return temResultado() && this.resultado.toLowerCase().contains("normal");
    }



    public int getIdExame() {
        return idExame;
    }

    public void setIdExame(int idExame) {
        this.idExame = idExame;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getRequisitos() {
        return requisitos;
    }

    public void setRequisitos(String requisitos) {
        this.requisitos = requisitos;
    }

    public String getResultado() {
        return resultado;
    }

    public void setResultado(String resultado) {
        this.resultado = resultado;
    }
}
