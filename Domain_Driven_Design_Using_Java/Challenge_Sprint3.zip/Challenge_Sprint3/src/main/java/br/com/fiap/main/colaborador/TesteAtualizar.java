package br.com.fiap.main.colaborador;

import br.com.fiap.dao.ColaboradorDAO;
import br.com.fiap.entities.Colaborador;

import javax.swing.*;
import java.sql.SQLException;

public class TesteAtualizar {

    static String texto(String j) {
        return JOptionPane.showInputDialog(j);
    }

    static int inteiro(String j) {
        return Integer.parseInt(JOptionPane.showInputDialog(j));
    }

    public static void main(String[] args) throws SQLException, ClassNotFoundException {

        Colaborador colaborador = new Colaborador();
        ColaboradorDAO dao = new ColaboradorDAO();

        colaborador.setIdColaborador(inteiro("ID do Colaborador que será atualizado"));
        colaborador.setNome(texto("Novo Nome"));
        colaborador.setEmail(texto("Novo Email"));
        colaborador.setSenha(texto("Nova Senha"));
        colaborador.setCargo(texto("Novo Cargo"));
        colaborador.setDisponibilidade(texto("Nova Disponibilidade (sim/nao)"));

        System.out.println(dao.atualizar(colaborador));
    }
}
