package br.com.fiap.main.notificacao;

import br.com.fiap.dao.NotificacaoDAO;

import javax.swing.*;
import java.sql.SQLException;

public class TesteDeletar {

    static int inteiro(String j) {
        return Integer.parseInt(JOptionPane.showInputDialog(j));
    }

    public static void main(String[] args) throws SQLException, ClassNotFoundException {

        NotificacaoDAO dao = new NotificacaoDAO();

        int id = inteiro("Informe o ID da notificação que será deletada");

        System.out.println(dao.deletar(id));
    }
}
