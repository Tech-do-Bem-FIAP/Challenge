package br.com.fiap.main.dentista;

import br.com.fiap.dao.DentistaDAO;
import br.com.fiap.entities.Dentista;

import javax.swing.*;
import java.sql.SQLException;

public class TesteSelecionarPorCodigo {

    static int inteiro(String j) {
        return Integer.parseInt(JOptionPane.showInputDialog(j));
    }

    public static void main(String[] args) throws SQLException, ClassNotFoundException {

        DentistaDAO dao = new DentistaDAO();

        int id = inteiro("Informe o ID do dentista que gostaria de verificar");

        Dentista d = dao.selecionarPorId(id);

        if (d != null) {
            System.out.println(
                    d.getIdDentista() + " | " +
                    d.getNome() + " | " +
                    d.getEmail() + " | " +
                    d.getCro() + " | " +
                    d.getDisponibilidade()
            );
        } else {
            System.out.println("Dentista não encontrado!");
        }
    }
}
