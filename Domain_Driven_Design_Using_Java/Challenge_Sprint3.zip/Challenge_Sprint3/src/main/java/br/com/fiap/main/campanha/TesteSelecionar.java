package br.com.fiap.main.campanha;

import br.com.fiap.dao.CampanhaDAO;
import br.com.fiap.entities.Campanha;

import java.sql.SQLException;
import java.util.ArrayList;

public class TesteSelecionar {

    public static void main(String[] args) throws SQLException, ClassNotFoundException {

        CampanhaDAO dao = new CampanhaDAO();

        ArrayList<Campanha> lista = dao.selecionar();

        if (lista != null) {
            for (Campanha c : lista) {
                System.out.println(
                        c.getIdCampanha() + " | " +
                        c.getNome() + " | " +
                        c.getLocal() + " | " +
                        c.getDataInicio() + " | " +
                        c.getDataFim()
                );
            }
        }
    }
}
